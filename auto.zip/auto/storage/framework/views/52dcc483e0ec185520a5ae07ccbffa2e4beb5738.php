resources/views/products/layout.blade.php

<!DOCTYPE html>
<html>
<head>
    <title>Laravel 9 CRUD Application - ItSolutionStuff.com</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
    
</body>
</html><?php /**PATH C:\wamp64\www\auto\resources\views/products/layout.blade.php ENDPATH**/ ?>